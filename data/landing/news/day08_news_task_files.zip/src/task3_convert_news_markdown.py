"""
Task 3 - Convert crawled news JSON files to Markdown.

Input:
data/landing/news/article_01.json
...

Output:
data/standardized/news/article_01.md
...
"""

import json
import re
from pathlib import Path


IN_DIR = Path("data/landing/news")
OUT_DIR = Path("data/standardized/news")


def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text, flags=re.UNICODE)
    text = re.sub(r"[\s_-]+", "-", text)
    return text.strip("-")[:80] or "article"


def yaml_escape(value) -> str:
    if value is None:
        return ""
    return str(value).replace('"', '\\"')


def clean_markdown(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def convert_one(json_file: Path):
    article = json.loads(json_file.read_text(encoding="utf-8"))

    title = article.get("title", "Untitled article")
    url = article.get("url", "")
    source = article.get("source", "")
    crawl_date = article.get("crawl_date", "")
    source_type = article.get("source_type", "news")
    content = clean_markdown(article.get("content", ""))

    md = f"""---
title: "{yaml_escape(title)}"
url: "{yaml_escape(url)}"
source: "{yaml_escape(source)}"
crawl_date: "{yaml_escape(crawl_date)}"
source_type: "{yaml_escape(source_type)}"
original_file: "{json_file.name}"
---

# {title}

{content}
"""

    out_file = OUT_DIR / f"{json_file.stem}.md"
    out_file.write_text(md, encoding="utf-8")
    return out_file


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    json_files = sorted(IN_DIR.glob("article_*.json"))
    if not json_files:
        raise FileNotFoundError("No article_*.json files found in data/landing/news/")

    for json_file in json_files:
        out_file = convert_one(json_file)
        print(f"Converted: {json_file} -> {out_file}")


if __name__ == "__main__":
    main()
