"""
Task 2 - Crawl 5 news articles with Crawl4AI.

Output:
data/landing/news/article_01.json
data/landing/news/article_02.json
...

Each JSON contains:
url, title, source, crawl_date, content, source_type
"""

import asyncio
import json
import re
from datetime import date
from pathlib import Path
from urllib.parse import urlparse

from bs4 import BeautifulSoup

try:
    from crawl4ai import AsyncWebCrawler
except ImportError as exc:
    raise SystemExit(
        "Missing Crawl4AI. Install it with:\n"
        "pip install crawl4ai beautifulsoup4\n"
    ) from exc


URLS_FILE = Path("data/landing/news/news_urls.txt")
OUT_DIR = Path("data/landing/news")


def detect_source(url: str) -> str:
    domain = urlparse(url).netloc.lower()
    if "tuoitre.vn" in domain:
        return "Tuổi Trẻ"
    if "thanhnien.vn" in domain:
        return "Thanh Niên"
    if "muctim.tuoitre.vn" in domain:
        return "Mực Tím - Tuổi Trẻ"
    return domain


def clean_text(text: str) -> str:
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


def html_to_text(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")

    for tag in soup(["script", "style", "noscript", "iframe", "svg"]):
        tag.decompose()

    # Prefer article body if the site exposes it.
    candidates = []
    for selector in [
        "article",
        ".detail-content",
        ".contentdetail",
        ".main-content-body",
        ".article-content",
        ".detail__content",
        ".cms-body",
        "body",
    ]:
        found = soup.select_one(selector)
        if found:
            candidates.append(found.get_text("\n", strip=True))

    text = max(candidates, key=len) if candidates else soup.get_text("\n", strip=True)
    return clean_text(text)


def extract_title(html: str, fallback_markdown: str = "") -> str:
    soup = BeautifulSoup(html, "html.parser")

    for selector in [
        "meta[property='og:title']",
        "meta[name='title']",
        "title",
        "h1",
    ]:
        tag = soup.select_one(selector)
        if not tag:
            continue
        title = tag.get("content") if tag.name == "meta" else tag.get_text(" ", strip=True)
        if title:
            return clean_text(title)

    for line in fallback_markdown.splitlines():
        line = line.strip("# ").strip()
        if len(line) > 20:
            return line

    return "Untitled article"


async def crawl_one(crawler: AsyncWebCrawler, url: str, index: int) -> dict:
    result = await crawler.arun(url=url)

    html = getattr(result, "html", "") or ""
    markdown = getattr(result, "markdown", "") or ""

    title = extract_title(html, markdown)
    content = clean_text(markdown) if markdown and len(markdown) > 500 else html_to_text(html)

    return {
        "url": url,
        "title": title,
        "source": detect_source(url),
        "crawl_date": date.today().isoformat(),
        "source_type": "news",
        "content": content,
    }


async def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    if not URLS_FILE.exists():
        raise FileNotFoundError(f"Cannot find {URLS_FILE}")

    urls = [
        line.strip()
        for line in URLS_FILE.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]

    if len(urls) < 5:
        raise ValueError("Need at least 5 URLs in data/landing/news/news_urls.txt")

    async with AsyncWebCrawler(verbose=True) as crawler:
        for i, url in enumerate(urls, start=1):
            print(f"Crawling {i}/{len(urls)}: {url}")
            article = await crawl_one(crawler, url, i)

            out_file = OUT_DIR / f"article_{i:02d}.json"
            out_file.write_text(
                json.dumps(article, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

            print(f"Saved: {out_file}")
            print(f"Title: {article['title']}")
            print("-" * 80)


if __name__ == "__main__":
    asyncio.run(main())
